<?php
// created: 2015-11-10 05:33:07
$dictionary["crm_negocios"]["fields"]["crm_negocios_tasks"] = array (
  'name' => 'crm_negocios_tasks',
  'type' => 'link',
  'relationship' => 'crm_negocios_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_CRM_NEGOCIOS_TASKS_FROM_TASKS_TITLE',
);
