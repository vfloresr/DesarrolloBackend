<?php
// created: 2015-11-10 05:33:07
$dictionary["crm_negocios"]["fields"]["crm_negocios_opportunities"] = array (
  'name' => 'crm_negocios_opportunities',
  'type' => 'link',
  'relationship' => 'crm_negocios_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'side' => 'right',
  'vname' => 'LBL_CRM_NEGOCIOS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
