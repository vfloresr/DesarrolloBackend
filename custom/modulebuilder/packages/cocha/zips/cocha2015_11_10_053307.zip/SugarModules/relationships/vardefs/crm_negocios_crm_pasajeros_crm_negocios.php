<?php
// created: 2015-11-10 05:33:07
$dictionary["crm_negocios"]["fields"]["crm_negocios_crm_pasajeros"] = array (
  'name' => 'crm_negocios_crm_pasajeros',
  'type' => 'link',
  'relationship' => 'crm_negocios_crm_pasajeros',
  'source' => 'non-db',
  'module' => 'crm_pasajeros',
  'bean_name' => 'crm_pasajeros',
  'side' => 'right',
  'vname' => 'LBL_CRM_NEGOCIOS_CRM_PASAJEROS_FROM_CRM_PASAJEROS_TITLE',
);
