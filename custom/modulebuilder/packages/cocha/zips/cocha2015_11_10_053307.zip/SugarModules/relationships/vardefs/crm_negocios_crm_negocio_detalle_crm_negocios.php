<?php
// created: 2015-11-10 05:33:07
$dictionary["crm_negocios"]["fields"]["crm_negocios_crm_negocio_detalle"] = array (
  'name' => 'crm_negocios_crm_negocio_detalle',
  'type' => 'link',
  'relationship' => 'crm_negocios_crm_negocio_detalle',
  'source' => 'non-db',
  'module' => 'crm_negocio_detalle',
  'bean_name' => 'crm_negocio_detalle',
  'side' => 'right',
  'vname' => 'LBL_CRM_NEGOCIOS_CRM_NEGOCIO_DETALLE_FROM_CRM_NEGOCIO_DETALLE_TITLE',
);
